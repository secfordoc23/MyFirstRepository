"""
    Program: Starbucks Junior
    File: StarbucksJunior.py
    Author: Jason J Welch, Rita Allen, Eric Gavin
    Date: 9/26/2019
    Purpose: we are selling coffee for $2.00, tea for $1.75, and latte for $4.00;
         in three sizes: tall with price factor of 1, grande with price factor
         of 1.5, venti for price factor of 2

"""

from Validation import *

# constant variables
COFFEE_PRICE = 2.00
TEA_PRICE = 1.75
LATTE_PRICE = 4.00

TALL_PRICE_FACTOR = 1
GRANDE_PRICE_FACTOR = 1.5
VENTI_PRICE_FACTOR = 2


# ============= main() ================================
def main():

    while True:
        print("\tSTARBUCKS JUNIOR\t")
        print("\tPoint of Sales\t\n")

        userSelection = initial_menu()
        if userSelection == 2:
            break

        orderTotal = place_order()
        display_order(orderTotal)
# END main=============================================

# =============get_order===============================
def get_order(userSelection):
    if userSelection == 1:
        sizeSelection = size_initial_menu()
        total = calculate_order(sizeSelection, COFFEE_PRICE)
    elif userSelection == 2:
        sizeSelection = size_initial_menu()
        total = calculate_order(sizeSelection, TEA_PRICE)    
    else:
        sizeSelection = size_initial_menu()
        total = calculate_order(sizeSelection, LATTE_PRICE)
    return total
# END get_order =======================================


# ===========place_order===============================
def place_order():

    orderTotal = 0
    while True:
        
        print("MENU")
        print("\t1. Coffee")
        print("\t2. Tea")
        print("\t3. Latte")
        print("\t4. Order Complete")

        userSelection = menu_validation("Option Selection: ", 4)
        if userSelection == 4:
            break
        order = get_order(userSelection)
        orderTotal += float(order)
    return orderTotal
# END place_order==========================================


# ============initial_menu==========================
def initial_menu():

        print("Initial Menu")
        print("\t1. Place Order")
        print("\t2. Exit")
        userSelection = menu_validation("Option Selection: ", 2)

        return userSelection
# END initial_menu==========================================

# ============calculate_order========================
def calculate_order(sizeSelection, itemPrice):
    if sizeSelection == 1:
        total = itemPrice * TALL_PRICE_FACTOR
        
    elif sizeSelection == 2:
        total = itemPrice * GRANDE_PRICE_FACTOR
        
    else:
        total = itemPrice * VENTI_PRICE_FACTOR
    return total
# END calculate_order====================================


# ============size_initial_menu==========================
def size_initial_menu():
    print("MENU")
    print("\t1. Tall")
    print("\t2. Grande")
    print("\t3. Venti")

    sizeSelection = menu_validation("Select size: ", 3)
    return sizeSelection
# END size_initial_menu==================


# ============display_order==========================
def display_order(total):
    print("\n\n\nOrder Total", format(total, ',.2f'))


# call main function
main()
