"""
    Program: Validation
    File: Validation.py
    Author: Jason J Welch, Rita Allen, Eric Gavin
    Date: 9/26/2019
    Purpose: Collection of methods for validation

"""

#===================inputNumber()==============
def inputNumber(message):
    while True:
        try:
            userInput = int(input(message))
        except ValueError:
            print("That is not an integer! Try again!")
            continue
        else:
            return userInput
        break
#END inputNumber()=============================


    
# ==================== input_decimal() ===================
def input_decimal(message):
    while True:
        try:
            while True:
                userInput = float(input(message))
                if 0 > userInput > 1:
                    print("Please enter a decimal between 0 and 1!")
                else:
                    break
        except ValueError:
            print("That is not a number! Please try again.")
            continue
        else:
            return userInput
            break
# end input_number=======================================



#================== menu_validation=========================
def menu_validation(message, numberOfOptions):
    while True:
        try:
            while True:
                userInput = int(input(message))
                if 1 > userInput or userInput > numberOfOptions:
                    print("Please enter a valid menu choice: ")
                else:
                    break
        except ValueError:
            print("That is not a number! Please try again.")
            continue
        else:
            return userInput
            break
#END menu_validation=======================================
